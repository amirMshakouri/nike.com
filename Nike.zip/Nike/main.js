axios.get("http://localhost:3000/banner")
.then(function(res){
    let data = res.data
    const banner = document.getElementById("banner")
    let html = `
    <img src="${data[0].url}" alt=""/>  
    `
    banner.innerHTML = html
})
.catch(function(error){
    console.log(error)
})

axios.get("http://localhost:3000/events")
.then(function(res){
    let data = res.data
    const events = document.getElementById("events")
    let html = `
        <div class="event-top">
            <h1>${data[0].title}</h1>
            <p>${data[0].text1}</p>
            <p>${data[0].text2}</p>
            <a href="#"><button>${data[0].button1}</button></a>
            <a href="#"><button>${data[0].button2}</button></a>
            <a href="#"><button>${data[0].button3}</button></a>
        </div>
        
        <div class="event-bottom">
            <a href="#"><img src="${data[1].url}" alt=""/></a>  
            <a href="#"><img src="${data[2].url}" alt=""/></a>  
            <a href="#"><img src="${data[3].url}" alt=""/></a>  
        </div>
  
    `
    events.innerHTML = html
})

axios.get("http://localhost:3000/trending")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <div class="item">
                <a href="#"><img src="${elem.url}" alt=""></a>
                <p>${elem.text}</p>
            </div>
        `
        return html
    })
    const items = document.getElementById("items")
    items.innerHTML = a
})

axios.get("http://localhost:3000/featured")
.then(function(res){
    let data = res.data
    const featured_cards = document.getElementById("featured-cards")
    let html = `
        <div class="featured-card">
            <img src="${data[0].url}" alt="">
            <h4>${data[0].title}</h4>
            <h3>${data[0].text}</h3>
            <a><button>${data[0].button}</button></a>
            </div> 
        <div class="featured-card">
            <img src="${data[1].url}" alt="">
            <h4>${data[1].title}</h4>
            <h3>${data[1].text}</h3>
            <a><button>${data[0].button}</button></a>
        </div> 
    `
    featured_cards.innerHTML=html
})

axios.get("http://localhost:3000/iconic")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <div class="iconic-item">
                <a href="#"><img src="${elem.url}" alt=""></a>
            </div>
        `
        return html
    })
    const iconic_items = document.getElementById("iconic-items")
    iconic_items.innerHTML = a
})

axios.get("http://localhost:3000/sport")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <div class="sport-item">
                <a href="#">
                    <img src="${elem.url}" alt="">
                </a>
                <p>${elem.text}</p>
                </div>
        `
        return html
    })
    const sport_items = document.getElementById("sport-items")
    sport_items.innerHTML = a
})

axios.get("http://localhost:3000/popular")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <div class="popular-item">
                <a href="#">
                    <img src="${elem.url}" alt="">
                </a>
                <h4>${elem.text}</h4>
                <p>${elem.desc}</p>
                <span>${elem.price}</span>
            </div>
        `
        return html
    })
    const popular_items = document.getElementById("popular-items")
    popular_items.innerHTML = a
})

axios.get("http://localhost:3000/membership")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <div class="membership-item">
                <a href="#">
                    <img src="${elem.url}" alt="">
                </a>
                <h4>${elem.title}</h4>
                <h3>${elem.text}</h3>
                <a href="#"><button>${elem.button}</button></a>
            </div>
        `
        return html
    })
    const membership_items = document.getElementById("membership-items")
    membership_items.innerHTML = a
})

axios.get("http://localhost:3000/featured-colum")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <a href="">
                ${elem.text}
            </a>
        `
        return html
    })
    const featured_colum_items = document.getElementById("featured-colum-items")
    featured_colum_items.innerHTML = a
})

axios.get("http://localhost:3000/shoes-colum")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <a href="">
                ${elem.text}
            </a>
        `
        return html
    })
    const shoes_colum_items = document.getElementById("shoes-colum-items")
    shoes_colum_items.innerHTML = a
})

axios.get("http://localhost:3000/clothing-colum")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <a href="">
                ${elem.text}
            </a>
        `
        return html
    })
    const clothing_colum_items = document.getElementById("clothing-colum-items")
    clothing_colum_items.innerHTML = a
})

axios.get("http://localhost:3000/kids-colum")
.then(function(res){
    let data = res.data
    let a = data.map((elem)=>{
        html = `
            <a href="">
                ${elem.text}
            </a>
        `
        return html
    })
    const kids_colum_items = document.getElementById("kids-colum-items")
    kids_colum_items.innerHTML = a
})

const btn_open = document.getElementById("btn-open") 
const btn_close = document.getElementById("btn-close")
const slide_menu = document.getElementById("slide-menu")


btn_open.addEventListener("click", function(){
    slide_menu.style.right="0";
    document.getElementById("blur").style.cssText="z-index: 2; opacity: 1";
})
btn_close.addEventListener("click", function (){
    slide_menu.style.right="-300px";
    document.getElementById("blur").style.cssText="z-index: -1; opacity: 0";
})


 const main_menu = document.getElementById("menu")
 let lastscrollY = window.scrollY;

 window.addEventListener("scroll",()=>{
    if(lastscrollY<window.scrollY){
        main_menu.style.position="relative";
        main_menu.style.top="-100px";
    }else{
        main_menu.style.position="sticky";
        main_menu.style.top="0";
    }
    lastscrollY = window.scrollY;
 })